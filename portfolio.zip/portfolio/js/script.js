function prefersReducedMotion(){
  return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
}

document.addEventListener('DOMContentLoaded', () => {

  // Page loader
  const loader = document.getElementById('loader');
  window.addEventListener('load', () => {
    setTimeout(() => loader.classList.add('hidden'), 350);
  });
  // Fallback in case the load event already fired before the listener was attached
  if (document.readyState === 'complete'){
    setTimeout(() => loader.classList.add('hidden'), 350);
  }

  // Cursor-reactive hero glow
  const glowOrb = document.querySelector('.glow-orb');
  const supportsHover = window.matchMedia('(hover: hover)').matches;
  if (glowOrb && !prefersReducedMotion() && supportsHover){
    const hero = document.querySelector('.hero');
    hero.addEventListener('mousemove', (e) => {
      const rect = hero.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width - 0.5) * 40;
      const y = ((e.clientY - rect.top) / rect.height - 0.5) * 40;
      glowOrb.style.transform = `translate(${x}px, ${y}px)`;
    });
  }

  // Sticky nav on scroll
  const nav = document.getElementById('nav');
  const scrollProgress = document.getElementById('scrollProgress');
  const backToTop = document.getElementById('backToTop');

  function onScroll(){
    const y = window.scrollY;
    nav.classList.toggle('scrolled', y > 40);

    const docHeight = document.documentElement.scrollHeight - window.innerHeight;
    const progress = docHeight > 0 ? (y / docHeight) * 100 : 0;
    scrollProgress.style.width = progress + '%';

    backToTop.classList.toggle('visible', y > 500);
  }
  document.addEventListener('scroll', onScroll, { passive:true });
  onScroll();

  backToTop.addEventListener('click', () => {
    window.scrollTo({ top:0, behavior: prefersReducedMotion() ? 'auto' : 'smooth' });
  });

  // Mobile menu
  const hamburger = document.getElementById('hamburger');
  const navLinks = document.getElementById('navLinks');

  hamburger.addEventListener('click', () => {
    const isOpen = navLinks.classList.toggle('open');
    hamburger.classList.toggle('open', isOpen);
    hamburger.setAttribute('aria-expanded', isOpen);
  });

  navLinks.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      navLinks.classList.remove('open');
      hamburger.classList.remove('open');
      hamburger.setAttribute('aria-expanded', 'false');
    });
  });

  // Active nav link on scroll
  const sections = document.querySelectorAll('main section[id]');
  const navAnchors = document.querySelectorAll('[data-nav]');

  const navObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting){
        const id = entry.target.getAttribute('id');
        navAnchors.forEach(a => {
          a.classList.toggle('active', a.getAttribute('href') === `#${id}`);
        });
      }
    });
  }, { rootMargin: '-40% 0px -55% 0px', threshold: 0 });

  sections.forEach(section => navObserver.observe(section));

  // Scroll reveal
  const revealEls = document.querySelectorAll('[data-reveal]');
  if (prefersReducedMotion()){
    revealEls.forEach(el => el.classList.add('is-visible'));
  } else {
    const revealObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting){
          entry.target.classList.add('is-visible');
          revealObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15 });
    revealEls.forEach(el => revealObserver.observe(el));
  }

  // Theme toggle
  const themeToggle = document.getElementById('themeToggle');
  const themeIcon = themeToggle.querySelector('i');
  const root = document.documentElement;

  function applyTheme(theme){
    if (theme === 'light'){
      root.setAttribute('data-theme', 'light');
      themeIcon.classList.remove('fa-moon');
      themeIcon.classList.add('fa-sun');
    } else {
      root.removeAttribute('data-theme');
      themeIcon.classList.remove('fa-sun');
      themeIcon.classList.add('fa-moon');
    }
  }

  let savedTheme = 'dark';
  try { savedTheme = localStorage.getItem('ab-theme') || 'dark'; } catch(e) { /* storage unavailable */ }
  applyTheme(savedTheme);

  themeToggle.addEventListener('click', () => {
    const next = root.getAttribute('data-theme') === 'light' ? 'dark' : 'light';
    applyTheme(next);
    try { localStorage.setItem('ab-theme', next); } catch(e) { /* storage unavailable */ }
  });

  // Live clock in hero terminal
  const clockEl = document.getElementById('clock');
  function updateClock(){
    const now = new Date();
    clockEl.textContent = now.toLocaleTimeString('en-GB', { hour12:false });
  }
  updateClock();
  setInterval(updateClock, 1000);

  // Project filtering
  const filterBtns = document.querySelectorAll('.filter-btn');
  const projectCards = document.querySelectorAll('.project-card');

  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => { b.classList.remove('active'); b.setAttribute('aria-selected','false'); });
      btn.classList.add('active');
      btn.setAttribute('aria-selected','true');

      const filter = btn.dataset.filter;
      projectCards.forEach(card => {
        const cats = card.dataset.category.split(' ');
        const show = filter === 'all' || cats.includes(filter);
        card.classList.toggle('hide', !show);
      });
    });
  });

  // Download CV placeholder
  const downloadCV = document.getElementById('downloadCV');
  downloadCV.addEventListener('click', (e) => {
    e.preventDefault();
    alert('CV coming soon — add your CV file and link it here (e.g. assets/cv.pdf).');
  });

  // Contact form validation
  const form = document.getElementById('contactForm');
  const formNote = document.getElementById('formNote');

  const validators = {
    name: v => v.trim().length >= 2 ? '' : 'Please enter your name.',
    email: v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.trim()) ? '' : 'Please enter a valid email address.',
    subject: v => v.trim().length >= 3 ? '' : 'Please enter a subject.',
    message: v => v.trim().length >= 10 ? '' : 'Message should be at least 10 characters.'
  };

  function validateField(field){
    const input = document.getElementById(field);
    const error = validators[field](input.value);
    const row = input.closest('.form-row');
    const errorEl = document.getElementById(`${field}Error`);
    row.classList.toggle('invalid', !!error);
    errorEl.textContent = error;
    return !error;
  }

  Object.keys(validators).forEach(field => {
    document.getElementById(field).addEventListener('blur', () => validateField(field));
  });

  const submitBtn = form.querySelector('button[type="submit"]');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const results = Object.keys(validators).map(validateField);
    const isValid = results.every(Boolean);

    if (!isValid){
      formNote.style.color = '#e0685c';
      formNote.textContent = 'Please fix the errors above before sending.';
      return;
    }

    submitBtn.disabled = true;
    submitBtn.textContent = 'Sending…';

    try {
      const response = await fetch(form.action, {
        method: 'POST',
        body: new FormData(form),
        headers: { 'Accept': 'application/json' }
      });

      if (response.ok){
        formNote.style.color = 'var(--gold)';
        formNote.textContent = "Message sent — I'll get back to you soon.";
        form.reset();
      } else {
        throw new Error('Form service returned an error');
      }
    } catch (err){
      formNote.style.color = '#e0685c';
      formNote.textContent = "Something went wrong — please email me directly instead.";
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = 'Send Me a Message';
    }
  });

});
