# Abdullahi Bashir Inuwa — Portfolio

A single-page, vanilla HTML/CSS/JS portfolio (black / off-white / gold theme).

## Structure
```
portfolio/
├── index.html
├── css/
│   ├── style.css        # design tokens, layout, components
│   └── responsive.css   # breakpoints
├── js/
│   └── script.js        # nav, theme toggle, reveal animations, form validation
├── images/               # add your profile photo, project screenshots, certificates
├── assets/icons/         # extra icons if needed
└── README.md
```

## Before publishing — fill in the placeholders
Search the project for square brackets and replace them:
- `[YOUR PHONE]` is the only field still left as a placeholder — email, WhatsApp, and GitHub are already filled in
- Project "Code" / "Live Demo" links currently point to `#` — update once real URLs exist
- `#downloadCV` currently shows a placeholder alert — link it to a real PDF at `assets/cv.pdf` once ready (update the `href` and remove the JS placeholder in `script.js`)
- Certifications are marked "Learning / Planned" — update status only once actually completed

## Contact form
The form validates on the client, then submits to Formspree (`https://formspree.io/f/xvkzbdrw`) via
`fetch`, so messages arrive in your Formspree dashboard/inbox without a page reload. If you ever need
to swap the endpoint, update both the `action` attribute on the `<form>` in `index.html` and nothing
else — `script.js` reads `form.action` automatically.

## Local preview
Just open `index.html` in a browser — no build step required.
