# Understanding Your Portfolio Code
### A walkthrough to prepare you to explain and defend this project

This guide breaks down **what each file does, how it works, and why it was built that way** — so you can
answer any question a supervisor, lecturer, or interviewer throws at you.

---

## 1. The Big Picture

The site is built with **plain HTML, CSS, and JavaScript** — no frameworks, no build tools, no backend.
That means:

- You can open `index.html` directly in a browser and it works.
- There's nothing to install, compile, or configure.
- Every line of code is something you can point to and explain — nothing is hidden behind a framework.

```
portfolio/
├── index.html         ← structure & content (everything you see)
├── css/
│   ├── style.css       ← design system, layout, components
│   └── responsive.css  ← rules that adjust the layout per screen size
├── js/
│   └── script.js       ← interactivity (menus, animations, form, theme)
└── images/              ← your photo
```

**The one-sentence explanation you should be able to say out loud:**
> "It's a single-page site — one HTML file with numbered sections, styled with a token-based CSS system,
> and brought to life with a single JavaScript file that listens for scroll, click, and form events."

---

## 2. `index.html` — Structure

HTML is organized top to bottom in the same order the sections appear on the page: Navigation → Hero →
Marquee → About → Skills → Services → Projects → Experience → Education → Certifications → Career
Direction → Contact → Footer.

### Key things to notice and be able to explain:

**Semantic tags, not generic `<div>`s everywhere**
```html
<header class="nav">   <!-- not <div class="nav"> -->
<nav class="nav-links">
<main>
<section id="about">
<article class="project-card">
<footer class="footer">
```
Why: semantic HTML tells browsers and screen readers *what something is*, not just how it looks. This is
why the site passes basic accessibility checks.

**`data-*` attributes drive JavaScript behavior**
```html
<a href="#about" class="nav-link" data-nav>Home</a>
<div class="project-card" data-category="web">
<p data-reveal>...</p>
```
`data-nav`, `data-reveal`, and `data-category` are **hooks** — JavaScript searches for these attributes
to know which elements to animate, highlight, or filter. This keeps JS and HTML cleanly connected without
sprinkling IDs everywhere.

**`aria-*` attributes for accessibility**
```html
<button aria-label="Open menu" aria-expanded="false" aria-controls="navLinks">
```
`aria-label` gives screen readers a name for icon-only buttons. `aria-expanded` tells assistive tech
whether the mobile menu is open or closed — and the JS keeps this value in sync (see §4).

---

## 3. `css/style.css` — The Design System

### 3.1 CSS Custom Properties (design tokens)
At the very top:
```css
:root{
  --bg: #0a0a0a;
  --gold: #c9a24b;
  --font-display: 'Space Grotesk', sans-serif;
  --radius: 14px;
  --ease: cubic-bezier(.22,.68,.32,1);
}
```
These are **variables**. Instead of typing `#c9a24b` fifty times across the file, every gold accent
references `var(--gold)`. Change the value once, and the whole site updates.

**This is also how dark/light mode works:**
```css
[data-theme="light"]{
  --bg: #f7f6f2;
  --text: #131311;
}
```
When JavaScript adds `data-theme="light"` to the `<html>` tag, every `var(--bg)` and `var(--text)`
reference across the whole stylesheet instantly resolves to the light values. **No JS re-styling of
individual elements is needed** — that's the whole point of tokens.

### 3.2 Layout: Flexbox vs. Grid
Two layout tools are used, each for a different job:

| Tool | Used for | Example |
|---|---|---|
| **Flexbox** | One-dimensional rows (nav links, buttons, social icons) | `.nav-inner{ display:flex; justify-content:space-between; }` |
| **CSS Grid** | Two-dimensional layouts (cards in a grid, hero split in two columns) | `.services-grid{ display:grid; grid-template-columns:repeat(3,1fr); }` |

Rule of thumb you can state in defense: *"Flexbox for single rows or columns, Grid whenever content needs
to align in both rows and columns at once."*

### 3.3 The reveal-on-scroll pattern
```css
[data-reveal]{ opacity:0; transform:translateY(24px); transition:opacity .7s, transform .7s; }
[data-reveal].is-visible{ opacity:1; transform:translateY(0); }
```
CSS only defines the **two states** (hidden / visible) and the transition between them. JavaScript's only
job is to add the `.is-visible` class at the right time (see §4.3). This separation — CSS owns appearance,
JS owns timing — is a standard front-end pattern worth mentioning.

### 3.4 Accessibility: respecting reduced motion
```css
@media (prefers-reduced-motion: reduce){
  *,*::before,*::after{ animation-duration:0.001ms !important; transition-duration:0.001ms !important; }
}
```
If a visitor's operating system has "reduce motion" turned on, every animation on the site is effectively
disabled. This is a real accessibility requirement, not decoration — some users get dizzy or distracted by
motion.

---

## 4. `css/responsive.css` — Adapting to Screen Size

This file is deliberately separate from `style.css` so layout rules and responsive overrides don't get
mixed together. It uses `@media (max-width: ...)` breakpoints:

```css
@media (max-width: 860px){
  .nav-links{ position:fixed; transform:translateX(100%); }
  .nav-links.open{ transform:translateX(0); }
}
```

**How to explain the mobile menu in one line:** *"Below 860px, the nav links are hidden off-screen using
`transform: translateX(100%)`. JavaScript toggles an `.open` class that slides them back into view — the
animation itself is pure CSS."*

---

## 5. `js/script.js` — Interactivity

Everything runs inside one listener:
```js
document.addEventListener('DOMContentLoaded', () => { ... });
```
This guarantees the HTML is fully loaded before JavaScript tries to grab elements by ID — a very common
beginner bug is trying to access an element before the browser has parsed it.

Walk through each feature like this:

### 5.1 Page loader
```js
window.addEventListener('load', () => {
  setTimeout(() => loader.classList.add('hidden'), 350);
});
```
Waits for the `load` event (all images/fonts finished), then fades out the loading screen.

### 5.2 Scroll progress bar + sticky nav
```js
function onScroll(){
  const y = window.scrollY;
  nav.classList.toggle('scrolled', y > 40);
  const progress = (y / docHeight) * 100;
  scrollProgress.style.width = progress + '%';
}
document.addEventListener('scroll', onScroll, { passive:true });
```
On every scroll event, it calculates **how far down the page the user is** as a percentage, and sets the
progress bar's width directly. `{ passive:true }` tells the browser this listener won't block scrolling,
which keeps scrolling smooth.

### 5.3 `IntersectionObserver` — the most important concept to understand
Used twice: for the active nav-link highlight, and for scroll-reveal animations.
```js
const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting){
      entry.target.classList.add('is-visible');
      revealObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.15 });
```
**In plain English:** instead of checking scroll position manually (expensive and messy), the browser
itself tells you when an element enters the viewport. `threshold: 0.15` means "fire when 15% of the
element is visible." `unobserve` stops watching an element once it has revealed itself, since it never
needs to hide again — this is a small performance optimization.

This is the single most "I know what I'm doing" concept in the whole file — be ready to explain it clearly.

### 5.4 Theme toggle + `localStorage`
```js
try { localStorage.setItem('ab-theme', next); } catch(e) { /* storage unavailable */ }
```
Saves the chosen theme so it persists on refresh. Wrapped in `try/catch` because some browsers block
`localStorage` in private/incognito mode — without the `try/catch`, that would crash the script.

### 5.5 Project filtering
```js
const cats = card.dataset.category.split(' ');
const show = filter === 'all' || cats.includes(filter);
card.classList.toggle('hide', !show);
```
Each project card lists its categories in `data-category` (e.g. `"ai software"` for a project that's
both). Clicking a filter button just toggles a `.hide` class on cards that don't match — no page reload,
no server request.

### 5.6 Form validation
```js
const validators = {
  email: v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.trim()) ? '' : 'Please enter a valid email address.',
  ...
};
```
Each field has a small function that returns an empty string (valid) or an error message (invalid). The
regex for email checks for "something, then @, then something, then a dot, then something" — not a fully
strict email spec, but good enough for front-end validation.

**Once validation passes**, the form submits with `fetch` instead of a normal page reload:
```js
const response = await fetch(form.action, {
  method: 'POST',
  body: new FormData(form),
  headers: { 'Accept': 'application/json' }
});
```
`form.action` is the Formspree endpoint (`https://formspree.io/f/xvkzbdrw`) set in the HTML. `FormData(form)`
automatically collects every named input's value — no need to manually read each field. The `Accept:
application/json` header tells Formspree to respond with JSON instead of redirecting to a new page, so the
site can show a success or error message in place, without navigating away. The submit button is disabled
and shows "Sending…" while the request is in flight, so the user gets feedback and can't double-submit.

---

## 6. Likely Questions in a Defense — and How to Answer Them

**Q: Why didn't you use a framework like React or Bootstrap for everything?**
A: The brief called for a lightweight, dependency-free site. Vanilla HTML/CSS/JS loads faster, has no
build step, and every line is something I wrote and can explain — there's no framework "magic" hiding
behind it.

**Q: How does dark mode work without reloading the page?**
A: CSS custom properties. All colors are defined as variables under `:root`. A `[data-theme="light"]`
selector redefines those same variable names with light-mode values. JavaScript's only job is to toggle
one attribute on the `<html>` tag — the browser repaints instantly using the new variable values.

**Q: How do the sections fade in as I scroll?**
A: `IntersectionObserver` watches each `[data-reveal]` element and adds a `.is-visible` class the moment
it enters the viewport. CSS handles the actual fade/slide transition.

**Q: Is the contact form connected to anything?**
A: Yes — it validates input on the client side first (name, email format, subject, message length), then
submits to Formspree using `fetch`. Formspree receives the message and forwards it to my email, so no
custom backend was needed.

**Q: What happens if JavaScript fails to load?**
A: The page still renders and reads fine — nav links still work as anchor jumps, the layout is intact —
but interactive features like the mobile menu, theme toggle, and reveal animations won't function.

**Q: How did you make it responsive?**
A: CSS Grid/Flexbox layouts that naturally reflow, plus `responsive.css` with `@media` breakpoints at
1024px, 900px, 860px, 640px, and 375px that adjust column counts and the navigation for smaller screens.

---

## 7. If You Want to Practice

Try answering these out loud, from memory, without looking at the code:
1. What's the difference between `style.css` and `responsive.css`?
2. What does `data-reveal` do, and which file reads it?
3. Why is the theme toggle wrapped in `try/catch`?
4. What does `IntersectionObserver` replace, and why is it better?
5. What happens, step by step, when someone clicks the hamburger icon?

If you can answer all five without opening the files, you're ready.
